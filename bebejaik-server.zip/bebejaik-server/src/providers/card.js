/**
 * Card providers. The browser must send a TOKEN produced by your gateway's JS SDK / hosted fields
 * (never a raw card number). The server charges that token.
 *   charge(payment, token) -> { providerRef, state, message }
 *   parseWebhook(body)     -> { providerRef, state, receipt, message }
 */
const crypto = require("crypto");
const cfg = require("../config");

const mapState = (s) => {
  s = String(s || "").toLowerCase();
  if (["succeeded", "success", "paid", "captured", "completed", "approved"].includes(s)) return "PAID";
  if (["failed", "declined", "cancelled", "canceled", "error", "rejected"].includes(s)) return "FAILED";
  return "PENDING";
};

const demo = {
  async charge(p, token) {
    if (!token) throw new Error("Missing card token");
    return { providerRef: "DEMOCARD-" + p.id.slice(0, 8), state: "PAID", message: "Demo mode" };
  },
  parseWebhook: () => null
};

/* Generic server-to-server gateway (works as a template for Pesapal, Flutterwave, DPO, Stripe, bank gateways...). */
const gateway = {
  async charge(p, token) {
    const r = await fetch(cfg.card.base + cfg.card.path, {
      method: "POST",
      headers: { Authorization: "Bearer " + cfg.card.key, "Content-Type": "application/json", "Idempotency-Key": p.id },
      // TODO: rename fields to match your gateway's API
      body: JSON.stringify({
        amount: p.amount, currency: p.currency, source: token, reference: p.id,
        description: `${p.service} ${p.reference || ""}`.trim(),
        webhook_url: `${cfg.baseUrl}/api/payments/callback/card`
      })
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.message || j.error || "Card gateway rejected the request");
    return { providerRef: j.id || j.transaction_id || p.id, state: mapState(j.status), message: j.message || null };
  },
  /** Verify the HMAC-SHA256 signature header, then map the payload. */
  parseWebhook(body, rawBody, headers) {
    const sig = String(headers["x-signature"] || "");
    const expected = crypto.createHmac("sha256", cfg.card.webhookSecret).update(rawBody).digest("hex");
    const a = Buffer.from(sig), b = Buffer.from(expected);
    if (!cfg.card.webhookSecret || a.length !== b.length || !crypto.timingSafeEqual(a, b)) return { invalid: true };
    return { providerRef: body.id || body.transaction_id || body.reference, state: mapState(body.status), receipt: body.receipt || null, message: body.message || null };
  }
};

module.exports = ({ demo, gateway })[cfg.card.provider] || demo;
