/**
 * Mobile-money / bank "payment prompt" providers.
 * Every provider exposes:
 *   initiate(payment)            -> { providerRef }              sends the prompt to the customer's phone
 *   parseCallback(body)          -> { providerRef, state, receipt, message }  turns the bank's webhook into our format
 * state is always one of PENDING | PAID | FAILED.
 */
const cfg = require("../config");
const store = require("../paymentStore");

/* ---------------- DEMO: no money moves, "pays" after 6 seconds ---------------- */
const demo = {
  async initiate(p) {
    const providerRef = "DEMO-" + p.id.slice(0, 8);
    setTimeout(() => store.settle(providerRef, p.phone.endsWith("00") ? "FAILED" : "PAID", "DEMO" + Date.now(), "Demo mode"), 6000);
    return { providerRef };
  },
  parseCallback: () => null
};

/* ---------------- M-PESA DARAJA (Safaricom STK Push) ---------------- */
let tokenCache = { value: null, exp: 0 };
async function darajaToken() {
  if (tokenCache.value && Date.now() < tokenCache.exp) return tokenCache.value;
  const d = cfg.mobile.daraja;
  const r = await fetch(`${d.base}/oauth/v1/generate?grant_type=client_credentials`, {
    headers: { Authorization: "Basic " + Buffer.from(`${d.key}:${d.secret}`).toString("base64") }
  });
  if (!r.ok) throw new Error("Daraja auth failed: " + r.status);
  const j = await r.json();
  tokenCache = { value: j.access_token, exp: Date.now() + (+j.expires_in - 60) * 1000 };
  return tokenCache.value;
}
const darajaTimestamp = () => new Date().toISOString().replace(/\D/g, "").slice(0, 14); // YYYYMMDDHHmmss (UTC; Daraja accepts it)

const daraja = {
  async initiate(p) {
    const d = cfg.mobile.daraja, ts = darajaTimestamp();
    const body = {
      BusinessShortCode: d.shortcode,
      Password: Buffer.from(d.shortcode + d.passkey + ts).toString("base64"),
      Timestamp: ts,
      TransactionType: d.type,
      Amount: p.amount,
      PartyA: p.phone,
      PartyB: d.shortcode,
      PhoneNumber: p.phone,
      CallBackURL: `${cfg.baseUrl}/api/payments/callback/mobile/${cfg.callbackSecret}`,
      AccountReference: (p.reference || "BEBEJAIK").slice(0, 12),
      TransactionDesc: (p.service || "Payment").slice(0, 13)
    };
    const r = await fetch(`${d.base}/mpesa/stkpush/v1/processrequest`, {
      method: "POST",
      headers: { Authorization: "Bearer " + (await darajaToken()), "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || j.ResponseCode !== "0") throw new Error(j.errorMessage || j.ResponseDescription || "STK push rejected");
    return { providerRef: j.CheckoutRequestID };
  },
  parseCallback(body) {
    const cb = body?.Body?.stkCallback;
    if (!cb) return null;
    const items = Object.fromEntries((cb.CallbackMetadata?.Item || []).map((i) => [i.Name, i.Value]));
    return {
      providerRef: cb.CheckoutRequestID,
      state: cb.ResultCode === 0 ? "PAID" : "FAILED",
      receipt: items.MpesaReceiptNumber || null,
      message: cb.ResultDesc
    };
  }
};

/* ---------------- GENERIC BANK API (template: adapt to your bank's docs) ---------------- */
const bank = {
  async initiate(p) {
    const b = cfg.mobile.bank;
    const r = await fetch(b.base + b.path, {
      method: "POST",
      headers: { Authorization: "Bearer " + b.key, "Content-Type": "application/json" },
      // TODO: rename these fields to match your bank's request schema
      body: JSON.stringify({
        account: b.account, msisdn: p.phone, amount: p.amount, currency: p.currency,
        reference: p.id, narration: `${p.service} ${p.reference || ""}`.trim(),
        callbackUrl: `${cfg.baseUrl}/api/payments/callback/mobile/${cfg.callbackSecret}`
      })
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.message || "Bank rejected the request");
    return { providerRef: j.transactionId || j.id || p.id };   // TODO: map to your bank's response field
  },
  parseCallback(body) {
    // TODO: map your bank's webhook payload. Example shape assumed below.
    if (!body || !(body.transactionId || body.reference)) return null;
    const ok = ["SUCCESS", "PAID", "COMPLETED"].includes(String(body.status).toUpperCase());
    const failed = ["FAILED", "CANCELLED", "REJECTED"].includes(String(body.status).toUpperCase());
    return { providerRef: body.transactionId || body.reference, state: ok ? "PAID" : failed ? "FAILED" : "PENDING", receipt: body.receipt || null, message: body.message || null };
  }
};

const providers = { demo, daraja, bank };
module.exports = providers[cfg.mobile.provider] || demo;
