const db = require("./db");
const wa = require("./whatsapp");

exports.create = (p) => db.prepare(
  `INSERT INTO payments(id,method,service,reference,amount,currency,phone) VALUES(@id,@method,@service,@reference,@amount,@currency,@phone)`).run(p);
exports.get = (id) => db.prepare("SELECT * FROM payments WHERE id=?").get(id);
exports.setProviderRef = (id, ref) => db.prepare("UPDATE payments SET provider_ref=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(ref, id);

/** Move a payment to PAID/FAILED once (idempotent: callbacks are often delivered twice). */
exports.settle = (providerRef, state, receipt, message) => {
  const row = db.prepare("SELECT * FROM payments WHERE provider_ref=?").get(providerRef);
  if (!row || row.state !== "PENDING" || state === "PENDING") return row || null;
  db.prepare("UPDATE payments SET state=?,receipt=?,message=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(state, receipt || null, message || null, row.id);
  if (state === "PAID") {
    wa.notifyOwner(`💰 Payment received\n${row.currency} ${row.amount.toLocaleString()} via ${row.method}\nService: ${row.service}\nRef: ${row.reference || "-"}\nReceipt: ${receipt || "-"}`);
  }
  return { ...row, state };
};
