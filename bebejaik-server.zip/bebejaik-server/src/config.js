require("dotenv").config();
const e = process.env;
module.exports = {
  port: +e.PORT || 3000,
  baseUrl: (e.PUBLIC_BASE_URL || `http://localhost:${e.PORT || 3000}`).replace(/\/$/, ""),
  allowedOrigin: e.ALLOWED_ORIGIN || "",
  maxAmount: +e.MAX_AMOUNT_KES || 250000,
  currency: "KES",
  callbackSecret: e.CALLBACK_SECRET || "dev-secret",
  services: [
    "Security Assessment", "Data Protection / ODPC Support", "IT Forensics",
    "Software Development", "Training", "Funding Proposal Support", "Invoice Payment"
  ],
  mobile: {
    provider: e.MOBILE_PROVIDER || "demo",
    daraja: {
      base: e.DARAJA_ENV === "production" ? "https://api.safaricom.co.ke" : "https://sandbox.safaricom.co.ke",
      key: e.DARAJA_CONSUMER_KEY, secret: e.DARAJA_CONSUMER_SECRET,
      shortcode: e.DARAJA_SHORTCODE, passkey: e.DARAJA_PASSKEY,
      type: e.DARAJA_TRANSACTION_TYPE || "CustomerPayBillOnline"
    },
    bank: { base: e.BANK_BASE_URL, key: e.BANK_API_KEY, path: e.BANK_PUSH_PATH || "/v1/collections/stk", account: e.BANK_ACCOUNT }
  },
  card: {
    provider: e.CARD_PROVIDER || "demo",
    base: e.CARD_BASE_URL, key: e.CARD_SECRET_KEY,
    path: e.CARD_CHARGE_PATH || "/v1/charges", webhookSecret: e.CARD_WEBHOOK_SECRET || ""
  },
  wa: {
    number: (e.WHATSAPP_NUMBER || "254724850225").replace(/\D/g, ""),
    enabled: e.WA_ENABLED === "true",
    phoneId: e.WA_PHONE_NUMBER_ID, token: e.WA_ACCESS_TOKEN, appSecret: e.WA_APP_SECRET,
    verifyToken: e.WA_VERIFY_TOKEN || "", owner: (e.WA_OWNER_NUMBER || e.WHATSAPP_NUMBER || "").replace(/\D/g, ""),
    version: e.WA_API_VERSION || "v21.0"
  }
};
