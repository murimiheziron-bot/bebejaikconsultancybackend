/**
 * WhatsApp integration.
 *  1) Click-to-chat links (wa.me) – no API needed, used by the website buttons.
 *  2) WhatsApp Cloud API (Meta) – sends alerts to you and auto-replies to incoming messages.
 *     Note: business-initiated messages outside a 24-hour customer window must use an approved TEMPLATE
 *     in Meta Business Manager. Plain text (used below) works when the recipient messaged your number in the last 24h.
 */
const crypto = require("crypto");
const cfg = require("./config");
const db = require("./db");

exports.link = (text) => `https://wa.me/${cfg.wa.number}${text ? "?text=" + encodeURIComponent(text) : ""}`;

async function send(to, body) {
  db.prepare("INSERT INTO wa_messages(direction,wa_number,body) VALUES('out',?,?)").run(to, body);
  if (!cfg.wa.enabled) { console.log(`[whatsapp:disabled] -> ${to}: ${body.replace(/\n/g, " | ")}`); return false; }
  try {
    const r = await fetch(`https://graph.facebook.com/${cfg.wa.version}/${cfg.wa.phoneId}/messages`, {
      method: "POST",
      headers: { Authorization: "Bearer " + cfg.wa.token, "Content-Type": "application/json" },
      body: JSON.stringify({ messaging_product: "whatsapp", to, type: "text", text: { body: body.slice(0, 4000) } })
    });
    if (!r.ok) console.error("WhatsApp send failed", r.status, await r.text());
    return r.ok;
  } catch (err) { console.error("WhatsApp error", err.message); return false; }
}
exports.sendText = send;
exports.notifyOwner = (text) => (cfg.wa.owner ? send(cfg.wa.owner, text) : false);

/** Verify Meta's X-Hub-Signature-256 header on incoming webhooks. */
exports.validSignature = (rawBody, header) => {
  if (!cfg.wa.appSecret) return false;
  const expected = "sha256=" + crypto.createHmac("sha256", cfg.wa.appSecret).update(rawBody).digest("hex");
  const a = Buffer.from(String(header || "")), b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
};

const MENU = "Hello 👋 Welcome to Bebejaik Consulting Systems Limited.\nReply with a number:\n1️⃣ Cybersecurity & Data Protection (DPA/ODPC)\n2️⃣ IT Forensics\n3️⃣ Software & Application Development\n4️⃣ Tracking & Surveillance\n5️⃣ Training / Funding Proposals\n6️⃣ Payments\nOur team will reply shortly.";
const REPLIES = {
  "1": "Cybersecurity & Data Protection: assessments, DPA/ODPC compliance, hardening and monitoring. Tell us your organisation size and what you need.",
  "2": "IT Forensics: evidence-preserving investigation of incidents with a clear report. Briefly describe what happened.",
  "3": "Software development in Python, JavaScript and .NET, including DApps, PApps and SaaS. What would you like to build?",
  "4": "Tracking & Surveillance: CCTV, vehicle and asset tracking. Where and how many units?",
  "5": "We help with staff training, project writing and funding proposals. Which are you interested in?",
  "6": "You can pay online at our website's Pay Online section (mobile prompt or card), or ask us for an invoice here."
};
exports.autoReply = (text) => REPLIES[String(text).trim()] || MENU;
