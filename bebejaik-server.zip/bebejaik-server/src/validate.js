// Same rules as the front end, enforced again on the server (never trust the browser).
exports.normalisePhone = (v) => {
  let d = String(v || "").replace(/\D/g, "");
  if (d.startsWith("254")) d = d.slice(3);
  if (d.startsWith("0")) d = d.slice(1);
  return /^[17]\d{8}$/.test(d) ? "254" + d : null;
};
exports.clean = (v, max = 200) => String(v ?? "").replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, max);
exports.validEmail = (v) => !v || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
