const express = require("express");
const db = require("../db");
const wa = require("../whatsapp");
const { clean, validEmail } = require("../validate");
const router = express.Router();

router.post("/", (req, res) => {
  const b = req.body || {};
  const c = { name: clean(b.name, 100), company: clean(b.company, 100), email: clean(b.email, 120), phone: clean(b.phone, 30), service: clean(b.service, 80), message: clean(b.message, 1500) };
  if (!c.name) return res.status(400).json({ error: "Name is required." });
  if (!validEmail(c.email)) return res.status(400).json({ error: "Invalid email." });
  db.prepare("INSERT INTO contacts(name,company,email,phone,service,message) VALUES(@name,@company,@email,@phone,@service,@message)").run(c);
  wa.notifyOwner(`📩 New website enquiry\nName: ${c.name}\nCompany: ${c.company || "-"}\nPhone: ${c.phone || "-"}\nEmail: ${c.email || "-"}\nService: ${c.service}\n${c.message}`);
  res.status(201).json({ ok: true });
});
module.exports = router;
