const express = require("express");
const cfg = require("../config");
const db = require("../db");
const wa = require("../whatsapp");
const router = express.Router();

/* Click-to-chat link for the poster's number: /api/whatsapp/link?text=Hello  ->  redirects to wa.me */
router.get("/link", (req, res) => res.redirect(wa.link(String(req.query.text || "").slice(0, 500))));

/* Meta webhook verification (set this URL + WA_VERIFY_TOKEN in the Meta developer dashboard) */
router.get("/webhook", (req, res) => {
  if (req.query["hub.mode"] === "subscribe" && cfg.wa.verifyToken && req.query["hub.verify_token"] === cfg.wa.verifyToken)
    return res.status(200).send(String(req.query["hub.challenge"]));
  res.sendStatus(403);
});

/* Incoming WhatsApp messages: log, alert the owner, auto-reply with the menu */
router.post("/webhook", (req, res) => {
  if (!wa.validSignature(req.rawBody || Buffer.from(""), req.headers["x-hub-signature-256"])) return res.sendStatus(401);
  res.sendStatus(200); // acknowledge immediately; Meta retries on slow replies
  for (const entry of req.body?.entry || [])
    for (const ch of entry.changes || [])
      for (const m of ch.value?.messages || []) {
        const text = m.type === "text" ? m.text.body : `[${m.type}]`;
        db.prepare("INSERT INTO wa_messages(direction,wa_number,body) VALUES('in',?,?)").run(m.from, text);
        if (m.type === "text") wa.sendText(m.from, wa.autoReply(text));
        if (m.from !== cfg.wa.owner) wa.notifyOwner(`💬 WhatsApp from +${m.from}:\n${text}`);
      }
});
module.exports = router;
