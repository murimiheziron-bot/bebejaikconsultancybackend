const express = require("express");
const crypto = require("crypto");
const cfg = require("../config");
const store = require("../paymentStore");
const mobile = require("../providers/mobile");
const card = require("../providers/card");
const { normalisePhone, clean } = require("../validate");

const router = express.Router();

function parseOrder(b) {
  const amount = Math.round(Number(b.amount));
  if (!Number.isFinite(amount) || amount < 1 || amount > cfg.maxAmount) return { error: `Amount must be between 1 and ${cfg.maxAmount}.` };
  const service = cfg.services.includes(b.service) ? b.service : null;
  if (!service) return { error: "Unknown service." };
  return { value: { id: crypto.randomUUID(), service, reference: clean(b.reference, 30), amount, currency: cfg.currency } };
}

/* 1) Mobile prompt: customer enters their phone, we push a prompt to it */
router.post("/mobile/prompt", async (req, res) => {
  const o = parseOrder(req.body || {});
  if (o.error) return res.status(400).json({ error: o.error });
  const phone = normalisePhone(req.body.phone);
  if (!phone) return res.status(400).json({ error: "Invalid phone number." });
  const p = { ...o.value, method: "mobile", phone };
  store.create(p);
  try {
    const { providerRef } = await mobile.initiate(p);
    store.setProviderRef(p.id, providerRef);
    res.status(202).json({ id: p.id, state: "PENDING" });
  } catch (err) {
    console.error("mobile initiate failed:", err.message);
    store.setProviderRef(p.id, "failed-" + p.id);
    store.settle("failed-" + p.id, "FAILED", null, err.message);
    res.status(502).json({ error: "Could not send the payment prompt. Please try again." });
  }
});

/* 2) Card: browser sends a gateway TOKEN (never the card number) */
router.post("/card/charge", async (req, res) => {
  const o = parseOrder(req.body || {});
  if (o.error) return res.status(400).json({ error: o.error });
  const token = clean(req.body.token, 500);
  if (!token) return res.status(400).json({ error: "Missing card token." });
  const p = { ...o.value, method: "card", phone: null };
  store.create(p);
  try {
    const r = await card.charge(p, token);
    store.setProviderRef(p.id, r.providerRef);
    if (r.state !== "PENDING") store.settle(r.providerRef, r.state, null, r.message); // else wait for the webhook
    res.status(202).json({ id: p.id, state: r.state });
  } catch (err) {
    console.error("card charge failed:", err.message);
    store.setProviderRef(p.id, "failed-" + p.id);
    store.settle("failed-" + p.id, "FAILED", null, err.message);
    res.status(502).json({ error: "Card payment could not be processed." });
  }
});

/* 3) Status: the front end polls this until PAID / FAILED */
router.get("/status", (req, res) => {
  const row = store.get(clean(req.query.id, 64));
  if (!row) return res.status(404).json({ error: "Not found" });
  res.json({ state: row.state, receipt: row.receipt, message: row.state === "FAILED" ? row.message : null });
});

/* 4) Bank / M-Pesa webhook. The secret in the URL stops strangers posting fake "PAID" events. */
router.post("/callback/mobile/:secret", (req, res) => {
  const a = Buffer.from(req.params.secret), b = Buffer.from(cfg.callbackSecret);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.sendStatus(403);
  const evt = mobile.parseCallback(req.body);
  if (evt) store.settle(evt.providerRef, evt.state, evt.receipt, evt.message);
  res.json({ ResultCode: 0, ResultDesc: "Accepted" });
});

/* 5) Card gateway webhook (HMAC signature verified in the provider) */
router.post("/callback/card", (req, res) => {
  const evt = card.parseWebhook(req.body, req.rawBody || Buffer.from(""), req.headers);
  if (!evt) return res.sendStatus(404);
  if (evt.invalid) return res.sendStatus(401);
  store.settle(evt.providerRef, evt.state, evt.receipt, evt.message);
  res.sendStatus(200);
});

module.exports = router;
