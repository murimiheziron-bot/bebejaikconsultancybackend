const Database = require("better-sqlite3");
const path = require("path");
const db = new Database(path.join(__dirname, "..", "data", "bebejaik.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS payments(
  id TEXT PRIMARY KEY, method TEXT NOT NULL, service TEXT, reference TEXT,
  amount INTEGER NOT NULL, currency TEXT NOT NULL, phone TEXT,
  state TEXT NOT NULL DEFAULT 'PENDING',      -- PENDING | PAID | FAILED
  provider_ref TEXT, receipt TEXT, message TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_pay_provider ON payments(provider_ref);
CREATE TABLE IF NOT EXISTS contacts(
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, company TEXT, email TEXT, phone TEXT,
  service TEXT, message TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS wa_messages(
  id INTEGER PRIMARY KEY AUTOINCREMENT, direction TEXT, wa_number TEXT, body TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);
module.exports = db;
