# Bebejaik backend (Node.js 20+)

## Run
    npm install
    cp .env.example .env      # edit values
    npm start                 # http://localhost:3000  (serves the website from /public too)

Starts in DEMO mode: no money moves, WhatsApp alerts are printed to the console.

## Endpoints
| Method | Path | Purpose |
|---|---|---|
| POST | /api/payments/mobile/prompt | `{service,amount,phone,reference}` sends the prompt to the customer's phone |
| POST | /api/payments/card/charge | `{service,amount,token,reference}` charges a gateway token |
| GET  | /api/payments/status?id= | `{state: PENDING|PAID|FAILED}` polled by the website |
| POST | /api/payments/callback/mobile/:CALLBACK_SECRET | bank / M-Pesa webhook |
| POST | /api/payments/callback/card | card gateway webhook (HMAC `x-signature`) |
| POST | /api/contact | saves enquiry + WhatsApp alert to you |
| GET  | /api/whatsapp/link?text= | redirects to wa.me/254724850225 |
| GET/POST | /api/whatsapp/webhook | WhatsApp Cloud API verify + incoming messages (auto-reply menu) |

## Going live
1. **Hosting**: HTTPS domain, set `PUBLIC_BASE_URL`. Banks must reach `/api/payments/callback/...`. Run behind nginx, keep `.env` private.
2. **Mobile prompt**: `MOBILE_PROVIDER=daraja` (fill DARAJA_* keys) or `bank` and adapt the two TODO spots in `src/providers/mobile.js` to your bank's request/webhook fields. Register the callback URL shown in the bank portal: `PUBLIC_BASE_URL/api/payments/callback/mobile/CALLBACK_SECRET`.
3. **Card**: `CARD_PROVIDER=gateway`; adapt `src/providers/card.js` to your gateway. In `public/scripts.js`, implement `window.BebejaikGateway.tokenize()` with the gateway's hosted-fields SDK so raw card numbers never touch your server (PCI-DSS).
4. **WhatsApp API**: create a Meta app, add the WhatsApp product, set `WA_*` values and `WA_ENABLED=true`, point the webhook to `/api/whatsapp/webhook` with your verify token. Alerts to your own number need an approved template unless you messaged the number in the last 24h. The website's WhatsApp buttons use wa.me links and need no API.
5. Back up `data/bebejaik.db` (SQLite: payments, contacts, WhatsApp log) regularly.
