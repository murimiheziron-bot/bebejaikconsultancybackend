const path = require("path");
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const cfg = require("./src/config");

const app = express();
app.set("trust proxy", 1); // behind nginx / a load balancer

app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      "style-src": ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      "font-src": ["'self'", "https://fonts.gstatic.com"],
      "connect-src": ["'self'"],
      "frame-src": ["'self'"],      // add your card gateway's domain if it uses hosted-field iframes
      "upgrade-insecure-requests": cfg.baseUrl.startsWith("https") ? [] : null
    }
  }
}));

// Optional CORS when the front end is hosted on a different domain
if (cfg.allowedOrigin) {
  app.use("/api", (req, res, next) => {
    res.set({ "Access-Control-Allow-Origin": cfg.allowedOrigin, "Access-Control-Allow-Headers": "Content-Type", "Access-Control-Allow-Methods": "GET,POST,OPTIONS", Vary: "Origin" });
    if (req.method === "OPTIONS") return res.sendStatus(204);
    next();
  });
}

// Keep the raw body: needed to verify webhook signatures
app.use(express.json({ limit: "50kb", verify: (req, _res, buf) => { req.rawBody = buf; } }));

const limit = (max) => rateLimit({ windowMs: 60_000, limit: max, standardHeaders: true, legacyHeaders: false });
app.use("/api/payments/mobile", limit(8));
app.use("/api/payments/card", limit(8));
app.use("/api/payments/status", limit(60));
app.use("/api/contact", limit(6));

app.use("/api/payments", require("./src/routes/payments"));
app.use("/api/contact", require("./src/routes/contact"));
app.use("/api/whatsapp", require("./src/routes/whatsapp"));
app.get("/api/health", (_req, res) => res.json({ ok: true, mobile: cfg.mobile.provider, card: cfg.card.provider, whatsapp: cfg.wa.enabled }));

app.use(express.static(path.join(__dirname, "public"), { extensions: ["html"] }));
app.use("/api", (_req, res) => res.status(404).json({ error: "Not found" }));
app.use((err, _req, res, _next) => { console.error(err); res.status(500).json({ error: "Server error" }); });

app.listen(cfg.port, () => console.log(`Bebejaik server on ${cfg.baseUrl} (mobile=${cfg.mobile.provider}, card=${cfg.card.provider}, whatsapp=${cfg.wa.enabled ? "on" : "off"})`));
